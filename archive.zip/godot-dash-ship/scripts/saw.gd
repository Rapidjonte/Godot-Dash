extends CollisionShape2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var texture : Texture2D = $"..".texture
	if texture:
		shape.radius = (texture.get_width()*0.512)/2-16.582

func _process(delta: float) -> void:
	$"../TextureRect".rotation += delta * PI * 2
