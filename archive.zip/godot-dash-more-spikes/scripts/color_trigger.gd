extends TextureRect

@export var targetID : String
@export var targetColor : Color
@export var duration : float

@onready var character_body = get_node("../../CharacterBody2D")

func _ready() -> void:
	visible = false
	#unless in editor
	
	$Label.text = targetID
	if position.x <= -32:
		duration = 0
		var tween = create_tween()
		if targetID == "bg":
			tween.tween_property($"../../background/bg", "modulate", targetColor, duration)
		elif targetID == "g":
			tween.tween_property($"../../ground_tiles/g", "modulate", targetColor, duration)
			var tween2 = create_tween()
			tween2.tween_property($"../../borders/g", "modulate", targetColor, duration)
			var tween3 = create_tween()
			tween3.tween_property($"../../borders/g2", "modulate", targetColor, duration)
		elif targetID == "l":
			tween.tween_property($"../../ground_tiles/line", "modulate", targetColor, duration)
			var tween2 = create_tween()
			tween2.tween_property($"../../borders/line", "modulate", targetColor, duration)
			var tween3 = create_tween()
			tween3.tween_property($"../../borders/line2", "modulate", targetColor, duration)
				
		
		await tween.finished
		queue_free()

func _process(delta: float) -> void:
	if character_body.position.x >= position.x-32:
		var tween = create_tween()
		if targetID == "bg":
			tween.tween_property($"../../background/bg", "modulate", targetColor, duration)
		elif targetID == "g":
			tween.tween_property($"../../ground_tiles/g", "modulate", targetColor, duration)
			var tween2 = create_tween()
			tween2.tween_property($"../../borders/g", "modulate", targetColor, duration)
			var tween3 = create_tween()
			tween3.tween_property($"../../borders/g2", "modulate", targetColor, duration)
		elif targetID == "l":
			tween.tween_property($"../../ground_tiles/line", "modulate", targetColor, duration)
			var tween2 = create_tween()
			tween2.tween_property($"../../borders/line", "modulate", targetColor, duration)
			var tween3 = create_tween()
			tween3.tween_property($"../../borders/line2", "modulate", targetColor, duration)
				
		
		await tween.finished
		queue_free()
