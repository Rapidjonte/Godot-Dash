extends Area2D

var character_body
@export var boostStrength: float

func _ready():
	character_body = get_node("../../CharacterBody2D")
	$CollisionShape2D.disabled = false

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	if get_overlapping_bodies().find(character_body) != -1 and Input.is_action_pressed("jump") and (Global.bufferable or character_body.grounded):
		$CollisionShape2D.set_deferred("disabled", true)
		character_body.velocity.y = -boostStrength*(character_body.gravity/abs(character_body.gravity))
		Global.bufferable = false
