extends TextureRect

func _ready() -> void:
	var tween = create_tween()
	tween.tween_property(self, "scale", Vector2(0.35, 0.35), 0.4).from(Vector2(0.01, 0.01)).set_ease(Tween.EASE_OUT)
	var alphaTween = create_tween()
	alphaTween.tween_property(self, "modulate", Color(modulate.r, modulate.g, modulate.b, 0), 0.4).from(Color(modulate.r, modulate.g, modulate.b, 2)).set_ease(Tween.EASE_IN)
	await tween.finished
	queue_free()
