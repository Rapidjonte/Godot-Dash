extends Area2D

var character_body
@export var boostStrength: float
@export var spin: bool

var circle_scene: PackedScene = load("res://scenes/circle_effect.tscn")

func _ready():
	character_body = get_node("../../CharacterBody2D")
	$CollisionShape2D.disabled = false

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:
	if get_overlapping_bodies().find(character_body) != -1:
		get_viewport().set_input_as_handled()
		if Input.is_action_pressed("jump") and (Global.bufferable or (character_body.grounded and Input.is_action_just_pressed("jump"))):
			Global.flip_blocks.emit()
			character_body.gravity *= -1
			character_body.spinSpeed *= -1
			character_body.velocity.y += character_body.gravity * get_process_delta_time() * 0.1
			character_body.velocity.y *= 0
			character_body.up_direction.y *= -1
			character_body.jumpStrength *= -1
			
			$CollisionShape2D.set_deferred("disabled", true)
			character_body.velocity.y += boostStrength*(character_body.gravity/abs(character_body.gravity))
			Global.bufferable = false
			$GPUParticles2D.add_child(circle_scene.instantiate())

func _process(delta: float) -> void:
	if spin:
		$TextureRect.rotation += delta*1.7
