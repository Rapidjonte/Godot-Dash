extends Node2D

func _ready() -> void:
	Global.reset()
	$attempts.text = "Attempt " + str(Global.attempt)
	load_level()

func _process(delta: float) -> void:
	if not Global.paused:
		var progress = $CharacterBody2D.position.x / Global.endX
		$cam/Control/ProgressBar.value = progress*100
		if progress >= 1:
			complete()


func load_level():
	var instance = Global.level.instantiate()
	instance.position.y = 448
	add_child(instance)
	Global.paused = false

func complete():
	Global.paused = true
	$CharacterBody2D/CPUParticles2D.emitting = true
	$CharacterBody2D/sprite.visible = false
