extends Node

signal flip_blocks

var levelOffset = 448

var bufferable = false
var attempt = 0
var paused = false

func reset():
	attempt += 1
	bufferable = false

var level: PackedScene
func load_level(path: String):
	level = load(path)
	calculate_end(level.instantiate())

var endX = 128
func calculate_end(level: Node):
	endX = 128
	var margin = 192
	for node in level.get_children(true):
		if node.position.x > endX - margin:
			endX = node.position.x + margin

var circles = []
