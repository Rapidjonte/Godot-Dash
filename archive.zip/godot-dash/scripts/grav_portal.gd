extends CollisionShape2D

var character_body
@export var multiplier: int
@export var force: bool

var circle_scene: PackedScene = load("res://scenes/circle_effect.tscn")

func _ready():
	character_body = get_node("../../../CharacterBody2D")
	disabled = false

func _on_grav_portal_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body == character_body:
		var prevGrav = character_body.gravity
		
		set_deferred("disabled", true)
		if force:
			character_body.gravity = abs(character_body.gravity) * multiplier
		else:
			character_body.gravity *= multiplier
			
		if prevGrav != character_body.gravity:
			Global.flip_blocks.emit()
			if not Input.is_action_pressed("jump"):
				Global.bufferable = true
			character_body.spinSpeed *= -1
			character_body.velocity.y += character_body.gravity * get_process_delta_time() * 0.1
			character_body.velocity.y *= 0.474
			character_body.up_direction.y *= -1
			character_body.jumpStrength *= -1
			character_body.move_and_slide()
			var node = circle_scene.instantiate()
			node.scale = Vector2(0.35,0.35)
			add_child(node)
