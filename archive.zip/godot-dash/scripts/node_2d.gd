extends Node2D

func _ready() -> void:
	Global.reset()
	$attempts.text = "Attempt " + str(Global.attempt)
	load_level()

func _process(delta: float) -> void:
	queue_redraw()
	if not Global.paused:
		var progress = $CharacterBody2D.position.x / Global.endX
		$cam/Control/ProgressBar.value = progress*100
		if progress >= 1:
			complete()

func load_level():
	var instance = Global.level.instantiate()
	instance.position.y = 448
	add_child(instance)
	Global.paused = false

func complete():
	Global.paused = true
	$CharacterBody2D/CPUParticles2D.emitting = true
	$CharacterBody2D/sprite.visible = false

func _draw():
	for circle in Global.circles:
		circle[1] += get_process_delta_time()*400
		var targetRad = 100
		var percent = circle[1]/targetRad
		draw_arc(circle[0], circle[1], 0, TAU, 28, Color(1, 1, 1, 0.5-percent*0.5), 4)
		if circle[1] > targetRad:
			Global.circles.remove_at(Global.circles.find(circle))
