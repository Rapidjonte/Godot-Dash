extends CharacterBody2D

var paddingY = 96;

const NORMAL_SPEED = 10.41667
var speed = NORMAL_SPEED

const HALF_SPEED = 8.4
const DOUBLE_SPEED = 12.91667
const TRIPLE_SPEED = 15.667
const QUADRUPLE_SPEED = 19.2

@export var startPos: Vector2

@export var jumpStrength: float
@export var gravity: float
@export var max_velocity: float
@export var spinSpeed: float

@onready var sprite = $sprite
@onready var cam = $"../cam"

var grounded = false
var excessiveForce = 0
var maxExcessive = 160

var quick_jump_disable = false

func _ready() -> void:
	Global.flip_blocks.connect(gravity_changed)
	position = Vector2(startPos.x-32.0,startPos.y+386)
	
	var _material = $friction.process_material
	$friction.position.y = 60
	_material.direction = Vector3(12.125,-98.5,0)
	_material.gravity = Vector3(0,422.335,0)

func _process(delta: float) -> void:
	if Input.is_action_just_pressed("reset"):
		die(true)
	if Input.is_action_just_pressed("exit"):
		get_tree().change_scene_to_file("res://scenes/menu.tscn")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(delta: float) -> void:	
	if !Global.paused:
		$Area2D2/spinbox.rotation = $sprite.rotation
		position.x += 64 * delta * speed
		if not is_on_floor():
			$friction.emitting = false
			grounded = false
			velocity.y += gravity * delta
			sprite.rotation += spinSpeed * delta
			
			if excessiveForce > maxExcessive:
				excessiveForce= maxExcessive
			if excessiveForce < -maxExcessive:
				excessiveForce = -maxExcessive
				
			velocity.y += excessiveForce
			excessiveForce = velocity.y
			
			if velocity.y > max_velocity:
				velocity.y = max_velocity
			if velocity.y < -max_velocity:
				velocity.y = -max_velocity
				
			excessiveForce -= velocity.y
		else:
			excessiveForce = 0
			$friction.emitting = true
			grounded = true
			var target = deg_to_rad(round(rad_to_deg(sprite.rotation) / 90.0) * 90.0)
			sprite.rotation = lerp_angle(sprite.rotation, target, 30.0 * delta)	
		
		if Input.is_action_pressed("jump") and grounded and !quick_jump_disable:
			$friction.emitting = true
			Global.bufferable = false
			if velocity.y >= 0:
				velocity.y -= jumpStrength
		elif Input.is_action_just_released("jump"):
			Global.bufferable = true
		
		move_and_slide()
		collision_check()
	else:
		$friction.emitting = false
	
	update_cam(delta)
	
	quick_jump_disable = false
	
func update_cam(delta):
	var easing: float = 7.0 # higher = faster response
	
	var upper_limit = position.y + paddingY
	var lower_limit = position.y - paddingY
	
	if Global.camera_y_lock == 0:
		if cam.position.y > upper_limit:
			cam.position.y = lerp(cam.position.y, upper_limit, easing * delta)
		elif cam.position.y < lower_limit:
			cam.position.y = lerp(cam.position.y, lower_limit, easing * delta)
	else:
		cam.position.y = lerp(cam.position.y, Global.camera_y_lock+124, easing * delta)
		
	if cam.position.x < position.x:
		cam.position.x = position.x

func collision_check():
	if Global.paused:
		return
	
	for i in get_slide_collision_count():
		var collision = get_slide_collision(i)
		if collision.get_collider().name.contains("spike"):
			die()

func _on_area_2d_body_entered(body: Node2D) -> void:
	if Global.paused:
		return
	if body.name.contains("block") or body.name.contains("ground"):
		die()

func die(instant: bool = false):
	Global.paused = true
	
	if not instant:
		# enable hitboxess
		await get_tree().create_timer(1).timeout
		# disable hitboxes
	
	get_tree().reload_current_scene.call_deferred()

func gravity_changed():
	var _material = $friction.process_material
	if $friction.position.y == 60:
		$friction.position.y = 3
		_material.direction = Vector3(12.125,98.5,0)
		_material.gravity = Vector3(0,-422.335,0)
	else:
		$friction.position.y = 60
		_material.direction = Vector3(12.125,-98.5,0)
		_material.gravity = Vector3(0,422.335,0)

func is_divisible_by_90(value: float, epsilon: float = 0.001) -> bool:
	var remainder = fmod(value, 90.0)
	return abs(remainder) < epsilon or abs(remainder - 90.0) < epsilon

func _on_area_2d_2_body_entered(body: Node2D) -> void:
	if Global.paused:
		return
	if body.name.contains("spike") and !is_divisible_by_90(rad_to_deg(body.rotation)):
		print(body.rotation)
		die()
