extends RigidBody2D

@export var texture: Texture
@export var disable_collision: bool
@export var H_block: bool

func _ready() -> void:
	if texture != null and $TextureRect:
		$TextureRect.texture = texture
	if disable_collision != null and $CollisionShape2D:
		$CollisionShape2D.disabled = disable_collision
	if H_block:
		$CollisionShape2D.one_way_collision = false
