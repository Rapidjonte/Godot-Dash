extends CollisionShape2D

var character_body
@export var targetSpeed: float


func _ready():
	character_body = get_node("../../../CharacterBody2D")
	disabled = false

func _on_area_2d_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body == character_body:
		set_deferred("disabled", true)
		character_body.speed = targetSpeed
		Global.circles.push_back([Vector2($"..".position.x,$"..".position.y+448),0])
