extends RigidBody2D

var offset: float
@onready var cam = $"../cam"

func _ready() -> void:
	offset = cam.position.x - position.x

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.x = cam.position.x - offset
